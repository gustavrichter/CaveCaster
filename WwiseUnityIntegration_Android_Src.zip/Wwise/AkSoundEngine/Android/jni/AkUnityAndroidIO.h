/*******************************************************************************
The content of this file includes portions of the proprietary AUDIOKINETIC Wwise
Technology released in source code form as part of the game integration package.
The content of this file may not be used without valid licenses to the
AUDIOKINETIC Wwise Technology.
Note that the use of the game engine is subject to the Unity(R) Terms of
Service at https://unity3d.com/legal/terms-of-service
 
License Usage
 
Licensees holding valid licenses to the AUDIOKINETIC Wwise Technology may use
this file in accordance with the end user license agreement provided with the
software or, alternatively, in accordance with the terms contained
in a written agreement between you and Audiokinetic Inc.
Copyright (c) 2022 Audiokinetic Inc.
*******************************************************************************/

#include <sys/types.h>
#include <android/asset_manager_jni.h>
#include <android/asset_manager.h>
#include <jni.h>

JavaVM* java_vm = NULL;
extern CAkFilePackageLowLevelIOBlocking g_lowLevelIO;

AKRESULT InitAndroidIO(jobject& out_jActivity)
{	
	if (java_vm == NULL)
		return AK_Fail;

	JNIEnv* lJNIEnv;
	java_vm->GetEnv((void**)&lJNIEnv, JNI_VERSION_1_6);

	jclass classActivity = lJNIEnv->FindClass("com/unity3d/player/UnityPlayer");
	jfieldID fieldActivity = lJNIEnv->GetStaticFieldID(classActivity, "currentActivity", "Landroid/app/Activity;");
	out_jActivity = lJNIEnv->GetStaticObjectField(classActivity, fieldActivity);
	
	g_lowLevelIO.Init(java_vm, out_jActivity);
	return AK_Success;
}

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
	java_vm = vm;
	return JNI_VERSION_1_6;		// minimum JNI version
}
